const quizData = {
  title: "Quize app Application"
};

const questions = [
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is My name ?",
    type: "mc",
    answers: [
      { text: "sujoy", correct: true },
      { text: "sumit", correct: false },
      { text: "Krish", correct: false},
      { text: "Akash", correct: false }
    ]
  },
  {
    text: "What is my favourite place ?",
    type: "mc",
    answers: [
      { text: "Delhi", correct: false },
      { text: "Maligram,pingla", correct: true },
      { text: "Kolkata", correct: false },
      { text: "Mumbai", correct: false }
    ]
  },
  {
    text: "What is my favourite place ?",
    type: "mc",
    answers: [
      { text: "Delhi", correct: false },
      { text: "Maligram,pingla", correct: true },
      { text: "Kolkata", correct: false },
      { text: "Mumbai", correct: false }
    ]
  }

];

module.exports = { quizData, questions };
